<div class="blog-post">
    <h2 class="blog-post-title">
        <a href="/posts/{{ $post->id }}">
            {{ $post->title }}
        </a>
    </h2>

    <p class="blog-post-meta">
        {{ $post->user->name }} on
        {{ $post->created_at->toFormattedDateString() }}
    </p>

    {{ str_limit($post->body, 150) }}
    <a href="/posts/{{ $post->id }}">Read more &raquo;</a>

    @if(Auth::check())
        <br>
        <a href="/posts/{{ $post->id }}/edit">Edit</a> |
        <a href="/posts/{{ $post->id }}/delete" onClick="return confirm('Are you sure you want to delete this post?')">Delete</a>
    @endif


</div><!-- /.blog-post -->