<?php

namespace App\Http\Controllers;

use App\Post;
use App\Comment;
use Illuminate\Http\Request;

class CommentsController extends Controller
{
    public function store(Post $post)
    {
        $this->validate(request(), ['body' => 'required|min:2']);

        $id = 0;

        if (auth()->user()) {
            $id = auth()->user()->id;
        }

        $post->addComment([
            'user_id' => $id,
            'body' => request('body')
        ]);

        return back();
    }
}
