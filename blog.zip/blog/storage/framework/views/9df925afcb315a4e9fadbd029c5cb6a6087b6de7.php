<?php $__env->startSection('content'); ?>
    <div class="col-sm-8 blog-main">
        <h1>Edit the Post</h1>

        <hr>

        <form method="post" action="/posts/<?php echo e($post->id); ?>">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo e($post->title); ?>">
            </div>

            <div class="form-group">
                <label for="body">Body:</label>
                <textarea name="body" id="body" rows="10" class="form-control"><?php echo e($post->body); ?></textarea>
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>

            <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </form>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>