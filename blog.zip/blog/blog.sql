-- MySQL dump 10.13  Distrib 5.7.17, for Linux (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	5.7.17-0ubuntu0.16.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `body` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,1,3,'Great!','2017-06-12 13:58:08','2017-06-12 13:58:08');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (17,'2014_10_12_000000_create_users_table',1),(18,'2014_10_12_100000_create_password_resets_table',1),(19,'2017_06_05_103841_create_posts_table',1),(20,'2017_06_06_113120_create_comments_table',1),(21,'2017_06_09_113846_create_tags_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_tag`
--

DROP TABLE IF EXISTS `post_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_tag` (
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`post_id`,`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tag`
--

LOCK TABLES `post_tag` WRITE;
/*!40000 ALTER TABLE `post_tag` DISABLE KEYS */;
INSERT INTO `post_tag` VALUES (1,1),(2,1),(3,2);
/*!40000 ALTER TABLE `post_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,1,'My First Post','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi varius ligula a magna pellentesque, at molestie massa blandit. Praesent posuere, libero lobortis viverra posuere, ex quam pellentesque mi, et ultrices turpis ligula non risus. Cras facilisis sem eget sapien tincidunt, non hendrerit odio placerat. Morbi at justo risus. Aliquam congue euismod elit, non commodo lectus dapibus eu. Nullam imperdiet dui vel ligula tincidunt, vel convallis sem rhoncus. Donec euismod nisl ac porttitor imperdiet. In aliquet ligula vel urna feugiat fermentum. Integer dapibus hendrerit vehicula. Maecenas elit lorem, finibus quis tortor vel, auctor consectetur metus. Aliquam erat volutpat.','2017-06-07 11:58:28','2017-06-07 11:58:28'),(2,1,'My Second Post','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sed facilisis erat, sit amet imperdiet purus. Quisque libero purus, eleifend ac tortor in, euismod consequat dolor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nulla dapibus hendrerit diam, ut mattis lacus iaculis et. Vestibulum volutpat velit in nulla ultricies, ut scelerisque dui ornare. Donec tincidunt, lectus vitae maximus faucibus, ligula justo imperdiet lorem, nec malesuada dolor augue et orci. Phasellus tincidunt nisl quis urna dignissim blandit. Fusce sit amet metus sed quam dignissim varius. Suspendisse a lectus pharetra felis rutrum dapibus. Fusce varius cursus lacinia. Aenean sed est ut erat dapibus placerat a in elit. Integer hendrerit neque a finibus rutrum. Donec ac ipsum tellus. Aenean tristique mauris sed nunc faucibus gravida. Etiam id dapibus quam, vitae fringilla sapien. Etiam laoreet, turpis eget facilisis rhoncus, lacus tellus pellentesque ligula, sit amet hendrerit libero tellus vel erat.','2017-08-06 12:17:01','2017-06-07 12:17:01'),(3,1,'Branislav\'s Thoughts','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempus justo vel dapibus tincidunt. Vestibulum quis diam sed sapien pretium pellentesque at id nunc. In nisi enim, consectetur vel facilisis sed, tristique eget dolor.','2017-08-07 13:20:42','2017-06-14 09:48:03'),(4,1,'Branislav\'s Thoughts','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempus justo vel dapibus tincidunt. Vestibulum quis diam sed sapien pretium pellentesque at id nunc. In nisi enim, consectetur vel facilisis sed, tristique eget dolor. Nullam scelerisque facilisis eros, id ultrices nisl pellentesque in. Nulla condimentum, neque et lobortis tempor, felis ligula sagittis est, quis dictum quam tortor nec nibh. Nulla sollicitudin justo et tempor fringilla. Phasellus vulputate velit nec tempus posuere. Proin ullamcorper mollis est et lacinia. Sed congue vitae sem ut fringilla. Pellentesque tincidunt maximus iaculis. Nunc porttitor diam neque, non ullamcorper diam molestie ac. Praesent cursus, eros et ullamcorper hendrerit, metus nisi sodales est, id ornare orci dolor sit amet dui. Nunc id eleifend mi, sed dignissim mauris. Quisque dictum blandit est, sollicitudin vehicula eros faucibus vel.','2016-05-07 13:20:42','2017-06-07 13:20:42'),(5,11,'Some Post','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi varius ligula a magna pellentesque, at molestie massa blandit. Praesent posuere, libero lobortis viverra posuere, ex quam pellentesque mi, et ultrices turpis ligula non risus. Cras facilisis sem eget sapien tincidunt, non hendrerit odio placerat. Morbi at justo risus. Aliquam congue euismod elit, non commodo lectus dapibus eu. Nullam imperdiet dui vel ligula tincidunt, vel convallis sem rhoncus. Donec euismod nisl ac porttitor imperdiet. In aliquet ligula vel urna feugiat fermentum. Integer dapibus hendrerit vehicula. Maecenas elit lorem, finibus quis tortor vel, auctor consectetur metus. Aliquam erat volutpat.','2017-06-09 11:26:01','2017-06-09 11:26:01');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,'personal','2017-06-09 11:42:57','2017-06-09 11:42:57'),(2,'php','2017-06-09 11:43:10','2017-06-09 11:43:10');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Branislav Subotić','branislav@example.com','$2y$10$qWjZiyBY8LpgxrL8BFrMnOERVtZFDK6mcjqcorBx9QruuVifvtdPi','rmDZx0gvbWItlOcg2pulEpQ7hxaqD53QjzfTKe7zkytrZDBUZ3627q0zRvvG','2017-06-07 13:19:21','2017-06-07 13:19:21'),(4,'Test','test@example.com','$2y$10$6IpOqKqOesOfiaFnnyE9ZuY8mjyj8ZpPUun/JDkbRDunOOoZQ6hnO','l9CmNYlnW14YojJNaXvG1u121rhZz4po8ST5kCjNpROKrf0cd3Flncj3DNhw','2017-06-08 13:47:28','2017-06-08 13:47:28'),(5,'Test2','test2@example.com','$2y$10$bVLa6Q0kQkAQTLUmrFLhYeBJYECg5zIdXvTvMMoFKGUm89K3927Zq','mFmmIla2NPvpaxB6I94zJ21GUB9SxfSK7CDWlo4KbkfiIcZkGbi5hv286o7a','2017-06-08 14:17:09','2017-06-08 14:17:09'),(9,'Pera Peric','pera@example.com','$2y$10$BIygVEMV7vYk8BnpXoRDhu1iezPqmLMmGUqkgd172b8IUmb1y7BEu','9KmKx6EmFxCM1yNw2EW0McP8KldA4TZDAWggA4lUkaKSNhES3KhZ7YVUudCe','2017-06-09 10:32:55','2017-06-09 10:32:55'),(10,'John Doe','john@example.com','$2y$10$UV4jVIU.VQqDmmPuaEFpwekmvgYuxBezqFXNYywERwHy3v/XohQGW','97uf1dc6iEgLO9M2Uxs978c3thxliZCtmLThABX3xPVFa5kwreN3KMcvWJi5','2017-06-09 10:35:45','2017-06-09 10:35:45'),(11,'Jane Doe','jane@example.com','$2y$10$ylxM0pT0lf6oFzMn/JqTcuRnilhSPXusHVB/masWmmo4doWncw58y','ShnjaQqM9VFTX3tUaMxWMiEvpgdVZvnAAbuAuDIaLlEum2lRzW4JbbbUisdJ','2017-06-09 11:25:30','2017-06-09 11:25:30');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-15 12:22:05
