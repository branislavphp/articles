<!-- Prikaz stranice za izmenu članka -->

<h2><?php echo $title; ?></h2>

<div class="row">
    <div class="col-md-9">

        <!-- Prikaz grešaka -->
        <?php echo validation_errors(); ?>

        <!-- Forma za izmenu članka -->
        <?php echo form_open_multipart(); ?>

        <div class="form-group">
            <label for="title">Naslov:</label>
            <input type="text" name="title" id="title" class="form-control" value="<?php echo $article['title'] ?>"
                   autofocus>
        </div>

        <div class="form-group">
            <label for="text">Tekst:</label>
            <?php echo $this->ckeditor->editor('text', $article['text']); ?>
        </div>

        <div class="form-group">
            <label for="userfile">Dodaj sliku:</label>
            <input type="file" name="userfile" id="userfile">
        </div>

        <input type="hidden" name="current_img" value="<?php echo $article['article_image']; ?>">

        <a href="<?php echo base_url('articles') ?>" class="btn btn-primary">Otkaži</a>

        <button type="submit" class="btn btn-primary">Izmeni članak</button>

        </form><!-- /Forma za izmenu članka -->

    </div>
</div>

<br>

<div class="row">
    <div class="col-md-3">

        <!-- Forma za brisanje slike -->
        <?php echo form_open('articles/delete_image') ?>

        <div class="form-group">
            <img class="img-responsive img-thumbnail"
                 src="<?php echo base_url(); ?>assets/images/articles/<?php echo $article['article_image']; ?>" alt="">
        </div>

        <input type="hidden" name="image" value="<?php echo $article['article_image']; ?>">
        <input type="hidden" name="id" value="<?php echo $article['id']; ?>">
        <button type="submit" class="btn btn-danger">Obriši</button>

        </form><!-- /Forma za brisanje slike -->

    </div>
</div>

<!-- /Prikaz stranice za izmenu članka -->
