<!-- Prikaz početne stranice (backend) -->

<br>

<a href="<?php echo base_url('articles/logout') ?>" class="btn btn-success">Odjava</a>

<h2>Dobro došao, <?php echo $name; ?>!</h2>

<a href="<?php echo base_url('articles/create') ?>" class="btn btn-primary">Dodaj novi članak</a>

<div class="row">
    <div class="col-md-12">

        <!-- Tabela za prikaz članaka-->
        <table class="table table-hover">
            <thead>
            <tr>
                <th>Naslov</th>
                <th class="text-right">Akcija</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($articles as $article): ?>
                <tr>
                    <td><?php echo $article['title']; ?></td>
                    <td class="text-right">

                        <a href="<?php echo base_url('articles/edit/' . $article['id']); ?>"
                           class="btn btn-success btn-sm"
                           title="Izmeni"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                        <a href="<?php echo base_url('articles/delete/' . $article['id']); ?>"
                           class="btn btn-danger btn-sm"
                           title="Obriši"
                           onClick="return confirm('Jesi li siguran da želiš da obrišeš članak?')"><i
                                    class="fa fa-minus-circle"
                                    aria-hidden="true"></i></a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table><!-- /Tabela za prikaz članaka-->

    </div>
</div>

<div class="row">
    <div class="col-md-12 text-center">

        <!-- Paginacija -->
        <?php echo $pagination; ?>

    </div>
</div>

<!-- /Prikaz početne stranice (backend) -->
