<!-- Prikaz stranice za dodavanje novog članka -->

<h2><?php echo $title; ?></h2>

<div class="row">
    <div class="col-md-9">

        <!-- Prikaz grešaka -->
        <?php echo validation_errors(); ?>

        <!-- Forma za dodavanje novog članka -->
        <?php echo form_open_multipart('articles/create'); ?>

        <div class="form-group">
            <label for="title">Naslov:</label>
            <input type="text" name="title" id="title" class="form-control" autofocus>
        </div>

        <div class="form-group">
            <label for="text">Tekst:</label>
            <?php echo $this->ckeditor->editor('text'); ?>
        </div>

        <div class="form-group">
            <label for="userfile">Dodaj sliku:</label>
            <input type="file" name="userfile" id="userfile">
        </div>

        <a href="<?php echo base_url('articles') ?>" class="btn btn-primary">Otkaži</a>

        <button type="submit" class="btn btn-primary">Dodaj članak</button>

        </form><!-- /Forma za dodavanje novog članka -->

    </div>
</div>

<!-- /Prikaz stranice za dodavanje novog članka -->
