<!-- Prikaz stranice za prijavu -->

<h2><?php echo $title; ?></h2>

<div class="row">
    <div class="col-md-4">

        <!-- Prikaz grešaka -->
        <?php echo validation_errors(); ?>

        <!-- Forma za prijavu -->
        <?php echo form_open('verify_login'); ?>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" class="form-control" autofocus>
        </div>

        <div class="form-group">
            <label for="password">Lozinka:</label>
            <input type="password" name="password" id="password" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Pristupi</button>

        </form><!-- /Forma za prijavu -->

    </div>
</div>

<!-- /Prikaz stranice za prijavu -->
