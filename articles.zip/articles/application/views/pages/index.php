<!-- Prikaz početne stranice (frontend) -->

<br>

<a href="<?php echo base_url('login') ?>" class="btn btn-success">Prijava</a>

<h1><?php echo $title; ?></h1>

<div class="row">
    <div class="col-md-12">

        <!-- Tabela za prikaz članaka-->
        <table class="table table-hover">
            <thead>
            <tr>
                <th>Naslov</th>
                <th class="text-right">Akcija</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($articles as $article): ?>
                <tr>
                    <td><?php echo $article['title']; ?></td>
                    <td class="text-right">
                        <a href="<?php echo base_url('pages/' . $article['slug']); ?>">Pogledaj više</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table><!-- /Tabela za prikaz članaka-->

    </div>
</div>

<div class="row">
    <div class="col-md-12 text-center">

        <!-- Paginacija -->
        <?php echo $pagination; ?>

    </div>
</div>

<!-- /Prikaz početne stranice (frontend) -->
