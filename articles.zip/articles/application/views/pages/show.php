<!-- Prikaz stranice sa konkretnim člankom -->

<br>

<a href="<?php echo base_url() ?>">Vrati se na listu članaka</a>

<h2><?php echo $article['title'] ?></h2>

<div class="row">
    <div class="col-md-12">
        <p><?php echo $article['text'] ?></p>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <img class="img-responsive img-thumbnail"
             src="<?php echo base_url(); ?>assets/images/articles/<?php echo $article['article_image']; ?>" alt="">
    </div>
</div>

<!-- /Prikaz stranice sa konkretnim člankom -->
