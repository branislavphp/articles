<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Verify_login extends CI_Controller
{
    /**
     * Verify_login konstruktor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
    }

    /**
     * Validacija unetih podataka pri prijavi.
     */
    public function index()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        $this->form_validation->set_rules('password', 'Lozinka', 'trim|required|callback_check_database');

        if ($this->form_validation->run() == false) {

            // Ako validacija polja nije prošla, korisnik se preusmerava na stranicu za prijavu
            $data['title'] = 'Prijava';

            $this->load->view('templates/header', $data);
            $this->load->view('articles/login', $data);
            $this->load->view('templates/footer');
        } else {

            // Preusmeravanje na početnu stranicu (backend)
            redirect(base_url('articles'));
        }
    }

    /**
     * Ručno napravljeno pravilo za validaciju.
     *
     * @param $password
     * @return bool
     */
    public function check_database($password)
    {
        // Ako je validacija polja prošla, vrši se validacija prema podacima iz baze
        $email = $this->input->post('email');

        $result = $this->user_model->login($email, $password);

        // Podešavanje sesije
        if ($result) {
            foreach ($result as $row) {
                $sess_array = [
                    'id' => $row->id,
                    'name' => $row->name,
                    'email' => $row->email
                ];
                $this->session->set_userdata('logged_in', $sess_array);
            }
            return true;
        } else {
            $this->form_validation->set_message('check_database', 'Neispravan email ili lozinka');
            return false;
        }
    }
}
