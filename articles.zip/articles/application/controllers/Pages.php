<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller
{
    /**
     * Pages konstruktor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('article_model');
        $this->load->library('pagination');
    }

    /**
     * Početna stranica (frontend).
     */
    public function index()
    {
        // Podešavanja paginacije
        $config['base_url'] = base_url('pages/index');
        $config['total_rows'] = $this->article_model->record_count();
        $config['per_page'] = 4;
        $config['uri_segment'] = 3;
        $choice = $config['total_rows'] / $config['per_page'];
        $config['num_links'] = floor($choice);

        // Podešavanja za integraciju klase Pagination sa Bootstrap-om
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);

        $data['pagination'] = $this->pagination->create_links();

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data['articles'] = $this->article_model->get_articles($config["per_page"], $page);
        $data['title'] = 'Lista članaka';

        $this->load->view('templates/header', $data);
        $this->load->view('pages/index', $data);
        $this->load->view('templates/footer');
    }

    /**
     * Prikaz konkretnog članka.
     *
     * @param null $slug
     */
    public function show($slug = null)
    {
        $data['article'] = $this->article_model->get_article_by_slug($slug);

        if (empty($data['article'])) {
            show_404();
        }

        $data['title'] = $data['article']['title'];

        $this->load->view('templates/header', $data);
        $this->load->view('pages/show', $data);
        $this->load->view('templates/footer');
    }
}
