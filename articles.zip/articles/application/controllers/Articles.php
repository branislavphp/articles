<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Articles extends CI_Controller
{
    /**
     * Articles konstruktor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('article_model');
        $this->load->library('pagination');
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

    /**
     * Početna stranica (backend).
     */
    public function index()
    {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            // Podešavanja paginacije
            $config['base_url'] = base_url('articles/index');
            $config['total_rows'] = $this->article_model->record_count();
            $config['per_page'] = 4;
            $config['uri_segment'] = 3;
            $choice = $config['total_rows'] / $config['per_page'];
            $config['num_links'] = floor($choice);

            // Podešavanja za integraciju klase Pagination sa Bootstrap-om
            $config['full_tag_open'] = '<ul class="pagination">';
            $config['full_tag_close'] = '</ul>';
            $config['first_link'] = false;
            $config['last_link'] = false;
            $config['first_tag_open'] = '<li>';
            $config['first_tag_close'] = '</li>';
            $config['prev_link'] = '&laquo';
            $config['prev_tag_open'] = '<li class="prev">';
            $config['prev_tag_close'] = '</li>';
            $config['next_link'] = '&raquo';
            $config['next_tag_open'] = '<li>';
            $config['next_tag_close'] = '</li>';
            $config['last_tag_open'] = '<li>';
            $config['last_tag_close'] = '</li>';
            $config['cur_tag_open'] = '<li class="active"><a href="#">';
            $config['cur_tag_close'] = '</a></li>';
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';

            $this->pagination->initialize($config);

            $data['pagination'] = $this->pagination->create_links();

            $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

            $data['name'] = $session_data['name'];
            $data['articles'] = $this->article_model->get_articles($config["per_page"], $page);
            $data['title'] = 'Upravljanje člancima';

            $this->load->view('templates/header', $data);
            $this->load->view('articles/manage', $data);
            $this->load->view('templates/footer');
        } else {

            redirect(base_url('login'));
        }
    }

    /**
     * CKEditor.
     *
     * @param $path
     * @param $width
     */
    public function editor($path, $width)
    {
        // Učitavanje klasa za Ckeditor
        $this->load->library('ckeditor');
        $this->load->library('ckfinder');

        // Podešavanja za CKEditor
        $this->ckeditor->basePath = base_url() . 'assets/js/ckeditor/';
        $this->ckeditor->config['toolbar'] = 'Full';
        $this->ckeditor->config['language'] = 'en';
        $this->ckeditor->config['width'] = $width;

        // Podešavanje CKFinder-a sa CKEditor config-om
        $this->ckfinder->SetupCKEditor($this->ckeditor, $path);
    }

    /**
     * Dodavanje novog članka.
     */
    public function create()
    {
        if ($this->session->userdata('logged_in')) {

            $data['title'] = 'Dodaj novi članak';

            $path = '../assets/js/ckfinder';
            $width = '850px';
            $this->editor($path, $width);

            $this->form_validation->set_rules('title', 'Naslov', 'required');
            $this->form_validation->set_rules('text', 'Tekst', 'required');

            if ($this->form_validation->run() === false) {
                $this->load->view('templates/header', $data);
                $this->load->view('articles/create');
                $this->load->view('templates/footer');
            } else {

                // Dodavanje slike
                $config['upload_path'] = './assets/images/articles';
                $config['allowed_types'] = 'jpg|jpeg|gif|png';
                $config['max_size'] = 2048;

                $this->load->library('upload', $config);

                if (! $this->upload->do_upload()) {

                    $article_image = 'noimage.jpg';
                } else {

                    $data['upload_data'] = $this->upload->data();
                    $filename = $_FILES['userfile']['name'];
                    $article_image = str_replace(" ", "_", $filename);
                }

                $this->article_model->set_article($article_image);
                redirect(base_url('articles'));
            }
        } else {

            redirect(base_url('login'));
        }
    }

    /**
     * Izmena članka.
     */
    public function edit()
    {
        if ($this->session->userdata('logged_in')) {

            $id = $this->uri->segment(3);

            if (empty($id)) {
                show_404();
            }

            $data['title'] = 'Izmeni članak';
            $data['article'] = $this->article_model->get_article_by_id($id);

            $path = '../assets/js/ckfinder';
            $width = '850px';
            $this->editor($path, $width);

            $this->form_validation->set_rules('title', 'Naslov', 'required');
            $this->form_validation->set_rules('text', 'Tekst', 'required');

            if ($this->form_validation->run() === false) {
                $this->load->view('templates/header', $data);
                $this->load->view('articles/edit', $data);
                $this->load->view('templates/footer');
            } else {

                // Dodavanje slike
                $config['upload_path'] = './assets/images/articles';
                $config['allowed_types'] = 'jpg|jpeg|gif|png';
                $config['max_size'] = 2048;

                $this->load->library('upload', $config);

                if (! $this->upload->do_upload()) {

                    $article_image = 'noimage.jpg';
                } else {

                    $data['upload_data'] = $this->upload->data();
                    $filename = $_FILES['userfile']['name'];
                    $article_image = str_replace(" ", "_", $filename);
                }

                $this->article_model->set_article($article_image, $id);

                if ($this->input->post('current_img') != 'noimage.jpg') {
                    unlink('./assets/images/articles/' . $this->input->post('current_img'));
                }

                redirect(base_url('articles'));
            }
        } else {

            redirect(base_url('login'));
        }
    }

    /**
     * Brisanje slike.
     */
    public function delete_image()
    {
        // Brisanje slike iz baze
        $this->db->set('article_image', 'noimage.jpg');
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('articles');

        // Brisanje slike iz foldera
        if (array_key_exists('image', $this->input->post())) {
            $filename = $this->input->post('image');

            if (file_exists('./assets/images/articles/' . $filename)) {
                unlink('./assets/images/articles/' . $filename);
            }
        }

        redirect(base_url('articles/edit/' . $this->input->post('id')));
    }

    /**
     * Brisanje članka.
     */
    public function delete()
    {
        $id = $this->uri->segment(3);

        if (empty($id)) {
            show_404();
        }

        $this->article_model->delete_article($id);
        redirect(base_url('articles'));
    }

    /**
     * Odjava i preusmeravanje na početnu stranicu (frontend).
     */
    function logout()
    {
        $this->session->unset_userdata('logged_in');
        session_destroy();
        redirect(base_url());
    }
}
