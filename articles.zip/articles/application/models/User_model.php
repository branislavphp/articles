<?php

class User_model extends CI_Model
{
    /**
     * Preuzimanje ulogovanog korisnika iz baze.
     *
     * @param $email
     * @param $password
     * @return bool
     */
    public function login($email, $password)
    {
        $this->db->select('id, name, email, password');
        $this->db->from('users');
        $this->db->where('email', $email);
        $this->db->where('password', sha1($password));
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result();
        } else {
            return false;
        }
    }
}
