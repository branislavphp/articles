<?php

class Article_model extends CI_Model
{
    /**
     * Broj članaka u bazi.
     *
     * @return mixed
     */
    public function record_count()
    {
        return $this->db->count_all('articles');
    }

    /**
     * Preuzimanje svih članaka iz baze.
     *
     * @param $limit
     * @param $offset
     * @return mixed
     */
    public function get_articles($limit, $offset)
    {

        $this->db->limit($limit, $offset);
        $query = $this->db->get('articles');
        return $query->result_array();
    }

    /**
     * Preuzimanje članka iz baze po slug-u.
     *
     * @param $slug
     * @return mixed
     */
    public function get_article_by_slug($slug)
    {
        $query = $this->db->get_where('articles', ['slug' => $slug]);
        return $query->row_array();
    }

    /**
     * Preuzimanje članka iz baze po id-u.
     *
     * @param int $id
     * @return mixed
     */
    public function get_article_by_id($id = 0)
    {
        if ($id === 0) {
            $query = $this->db->get('articles');
            return $query->result_array();
        }

        $query = $this->db->get_where('articles', ['id' => $id]);
        return $query->row_array();
    }

    /**
     * Unos članka u bazu (insert & update).
     *
     * @param $article_image
     * @param int $id
     * @return mixed
     */
    public function set_article($article_image, $id = 0)
    {
        $slug = url_title($this->input->post('title'), 'dash', true);

        $data = [
            'title' => $this->input->post('title'),
            'slug' => $slug,
            'text' => $this->input->post('text'),
            'article_image' => $article_image
        ];

        if ($id == 0) {
            return $this->db->insert('articles', $data);
        } else {
            $this->db->where('id', $id);
            return $this->db->update('articles', $data);
        }
    }

    /**
     * Brisanje članka iz baze.
     *
     * @param $id
     * @return mixed
     */
    public function delete_article($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('articles');
    }
}
